$(document).ready(function () {

	var $overlay = $('#overlay');
	var $body = $('body');

	$('.popupLink').on('click', function (e) {
		e.preventDefault();
		var popupId = $(this).attr('href');

		$(popupId).removeClass('-hide');
		$(popupId).removeClass('-hide');
		$overlay.removeClass('-hide');
		$body.addClass('popup_active');
	})

	$('#overlay, .close').on('click', function (e) {
		e.preventDefault();

		$('.popup').addClass('-hide');
		$overlay.addClass('-hide');
		$body.removeClass('popup_active');
	})

	$('.plant__rel_ques a').on('click', function (e) {
		e.preventDefault();
		var faqId = $(this).attr('href');

		$('.plant__rel_ques a').removeClass('-active');
		$(this).addClass('-active');

		$('.plant__info').addClass('-hide')
		$(faqId).removeClass('-hide')
	})

	$('.price_plan__buttons label').on('click', function () {
		var planId = $(this).data('id');

		$('.price_plan__select').addClass('-hide')
		$(planId).removeClass('-hide');
	});

});
